namespace RealEstateBlazor.Services;

public class INotification
{
    public DateTime Timestamp { get; }
}
