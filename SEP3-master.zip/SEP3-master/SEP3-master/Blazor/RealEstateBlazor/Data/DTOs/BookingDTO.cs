namespace RealEstateBlazor.Data.DTOs;

public class BookingDTO
{
    public long PropertyId { get; set; }
    public long AgentId { get; set; }
    public DateTime BookingDate { get; set; }
}
