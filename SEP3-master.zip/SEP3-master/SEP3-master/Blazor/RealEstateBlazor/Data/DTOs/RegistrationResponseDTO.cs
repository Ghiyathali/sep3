namespace RealEstateBlazor.Data.DTOs;

public class RegistrationResponseDTO
{
    public long AccountId { get; set; }
    public string Username { get; set; }
    public string Role { get; set; }
    public string FullName { get; set; }
}
