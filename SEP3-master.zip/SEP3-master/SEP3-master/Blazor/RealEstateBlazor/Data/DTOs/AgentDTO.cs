namespace RealEstateBlazor.Data.DTOs;

public class AgentDTO
{
    public long AgentId { get; set; }
    public string Name { get; set; }
    public string ContactInfo { get; set; }
}
