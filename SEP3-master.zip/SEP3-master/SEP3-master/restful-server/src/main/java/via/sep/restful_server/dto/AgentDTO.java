package via.sep.restful_server.dto;

import lombok.Data;

@Data
public class AgentDTO {
    private String name;
    private String contactInfo;
}
