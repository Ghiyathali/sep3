/*
package via.sep.restful_server.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import via.sep.restful_server.model.Booking;
import via.sep.restful_server.model.Forms;
import via.sep.restful_server.model.Property;

import java.util.List;
import java.util.Optional;

public interface FormRepository extends JpaRepository<Forms, Long> {

    Optional<Forms> findByFormID(Long formID);
}
*/
