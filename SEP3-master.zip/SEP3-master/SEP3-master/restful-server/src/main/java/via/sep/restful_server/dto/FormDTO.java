//package via.sep.restful_server.dto;
//
//import lombok.Data;
//
//import java.math.BigDecimal;
//
//@Data
//public class FormDTO {
//    private String propertyType;
//    private String address;
//    private String buildingName;
//    private BigDecimal floorArea;
//    private BigDecimal price;
//    private Integer numBedrooms;
//    private Integer numBathrooms;
//    private Integer numFloors;
//    private Boolean hasGarage;
//    private Boolean hasElevator;
//    private Boolean hasBalcony;
//    private Integer yearBuilt;
//    private String description;
//}
